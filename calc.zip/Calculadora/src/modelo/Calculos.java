package modelo;

public class Calculos
{
    public Integer n1;
    public Integer n2;
    public Integer resultado;
    
    public void somar()
    {
        this.resultado = this.n1 + this.n2;
    }
    
    public void substrair()
    {
        this.resultado = this.n1 - this.n2;
    }
}
