package modelo;


public class Validacao
{
    public String num1;
    public String num2;
    public Integer n1;
    public Integer n2;
    public String mensagem;
    
    public void validar()
    {
        this.mensagem = "";
        try
        {
            this.n1 = Integer.parseInt(num1);
            this.n2 = Integer.parseInt(num2);
        }
        catch (Exception e)
        {
            this.mensagem = "Numeros Invalidos";
        }
    }
}
